package Models;

public class Tool extends Item{

    public Tool(int count) {
        super(count);
    }
    
}
