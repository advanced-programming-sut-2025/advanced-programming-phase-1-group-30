package Models;

public enum StoneType {
    
}
