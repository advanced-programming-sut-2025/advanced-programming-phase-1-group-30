package Models;

public class Product extends Item{

    public Product(int count) {
        super(count);
    }
    
}
