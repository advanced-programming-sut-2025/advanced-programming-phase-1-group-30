package Models;

public class Fish {
    
}
