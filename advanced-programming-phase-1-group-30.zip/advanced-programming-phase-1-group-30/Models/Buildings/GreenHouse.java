package Models.Buildings;

public class GreenHouse extends Buildings {
    public GreenHouse(int lenght, int width, int startX, int startY) {
        super(lenght, width, startX, startY);
    }
}
