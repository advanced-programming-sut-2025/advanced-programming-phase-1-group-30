package Models.Buildings;

import java.util.ArrayList;

public class Farm {
    private Hut hut = new Hut();
    private GreenHouse greenHouse;
    private ArrayList<Lake> lakes = new ArrayList<>();
    private Quarry quarry;
    private ArrayList<Barn> barns = new ArrayList<>();
    private ArrayList<Coop> Coops = new ArrayList<>();

}
