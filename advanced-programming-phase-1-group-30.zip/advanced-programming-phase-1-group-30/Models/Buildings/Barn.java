package Models.Buildings;

public class Barn extends Buildings{

    public Barn(int lenght, int width, int startX, int startY) {
        super(lenght, width, startX, startY);
    }
}
