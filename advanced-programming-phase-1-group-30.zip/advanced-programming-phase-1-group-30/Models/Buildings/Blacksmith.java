package Models.Buildings;

import java.util.ArrayList;

public class Blacksmith extends Buildings {
    public Blacksmith(int lenght, int width, int startX, int startY) {
        super(lenght, width, startX, startY);
    }


}
