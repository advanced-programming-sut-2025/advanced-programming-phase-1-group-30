package Models.Buildings;

public class Quarry extends Buildings {
    public Quarry(int lenght, int width, int startX, int startY) {
        super(lenght, width, startX, startY);
    }
}
