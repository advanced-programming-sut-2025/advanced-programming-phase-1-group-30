package Models.Buildings;

public class Coop extends Buildings{
    public Coop(int lenght, int width, int startX, int startY) {
        super(lenght, width, startX, startY);
    }
}
