package Models.Buildings;

public class Lake extends Buildings {

    public Lake(int lenght, int width, int startX, int startY) {
        super(lenght, width, startX, startY);
    }
}
