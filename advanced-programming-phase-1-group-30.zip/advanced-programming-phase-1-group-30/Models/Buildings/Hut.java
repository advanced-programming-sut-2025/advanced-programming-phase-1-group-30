package Models.Buildings;

public class Hut extends Buildings {
    public Hut(int lenght, int width, int startX, int startY) {
        super(lenght, width, startX, startY);
    }
}
