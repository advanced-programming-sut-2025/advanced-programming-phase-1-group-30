package Models.Tools;

import Models.Tool;

public class Axe extends Tool {
    private AxeType type;

    public Axe(int count, AxeType type) {
        super(count);
        this.type = type;
    }

    public AxeType getType() {
        return type;
    }

    public void setType(AxeType type) {
        this.type = type;
    }
}
