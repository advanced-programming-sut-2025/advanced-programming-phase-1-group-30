package NPC;

import Buildings.BuildingsInfo;

public class Marnie extends NPC{
    public Marnie() {
        this.store = BuildingsInfo.Ranch;
    }
}
