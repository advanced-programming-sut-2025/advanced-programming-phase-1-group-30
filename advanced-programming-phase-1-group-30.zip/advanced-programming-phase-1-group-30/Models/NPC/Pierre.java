package NPC;

import Buildings.BuildingsInfo;

public class Pierre extends NPC {
    public Pierre() {
        this.store = BuildingsInfo.GeneralStore;
    }
}
