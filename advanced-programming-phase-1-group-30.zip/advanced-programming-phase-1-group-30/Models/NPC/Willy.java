package NPC;

import Buildings.BuildingsInfo;

public class Willy extends NPC {
    public Willy() {
        this.store = BuildingsInfo.FishShop;
    }
}
