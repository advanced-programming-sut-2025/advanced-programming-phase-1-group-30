package NPC;

import Buildings.BuildingsInfo;

public class Gus extends NPC {
    public Gus() {
        this.store = BuildingsInfo.StardropSaloon;
    }
}
