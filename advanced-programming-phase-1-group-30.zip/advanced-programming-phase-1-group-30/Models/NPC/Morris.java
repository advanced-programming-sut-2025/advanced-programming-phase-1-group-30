package NPC;

import Buildings.BuildingsInfo;

public class Morris extends NPC {
    public Morris() {
        this.store = BuildingsInfo.JojaMart;
    }
}
