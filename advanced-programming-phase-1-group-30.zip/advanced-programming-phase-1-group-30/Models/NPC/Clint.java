package NPC;

import Buildings.BuildingsInfo;

public class Clint extends NPC {
    public Clint() {
        this.store = BuildingsInfo.Blacksmith;
    }
}
