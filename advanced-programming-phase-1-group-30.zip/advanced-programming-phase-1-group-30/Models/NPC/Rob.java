package NPC;

import Buildings.BuildingsInfo;

public class Rob extends NPC {
    public Rob() {
        this.store = BuildingsInfo.CarpenterShop;
    }
}
