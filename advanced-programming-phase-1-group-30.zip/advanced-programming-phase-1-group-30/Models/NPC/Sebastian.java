package NPC;

public class Sebastian extends NPC {

}
