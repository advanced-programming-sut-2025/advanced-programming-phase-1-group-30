package modles;

public class Time {
}
