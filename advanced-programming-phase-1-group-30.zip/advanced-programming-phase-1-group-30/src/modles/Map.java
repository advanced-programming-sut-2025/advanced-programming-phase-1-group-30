package modles;

public class Map {
}
