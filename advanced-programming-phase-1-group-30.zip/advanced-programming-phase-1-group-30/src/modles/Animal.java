package modles;

public class Animal {
    private int price;
    private String name;
    private int friendship;
}
