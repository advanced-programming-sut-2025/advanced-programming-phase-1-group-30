package modles.enums;

public enum Weather {
}
