package modles.enums.Commands;

public enum RegisterMenuCommands {
}
