package modles.enums.Commands;

public enum MainMenuCommands {
}
