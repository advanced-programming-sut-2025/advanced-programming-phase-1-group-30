package modles.enums;

public enum Ability {
    Farming,
    Mining,
    Foraging,
    Fishing;

}
