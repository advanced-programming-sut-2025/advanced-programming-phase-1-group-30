package views;

public class ProfileMenu {
}
