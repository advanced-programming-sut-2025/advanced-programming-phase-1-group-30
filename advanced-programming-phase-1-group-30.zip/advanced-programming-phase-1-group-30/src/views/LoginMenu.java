package views;

public class LoginMenu {
}
