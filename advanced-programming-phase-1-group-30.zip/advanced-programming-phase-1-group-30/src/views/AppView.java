package views;

public class AppView {
}
