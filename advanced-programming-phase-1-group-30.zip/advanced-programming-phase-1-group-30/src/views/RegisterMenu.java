package views;

public class RegisterMenu {
}
