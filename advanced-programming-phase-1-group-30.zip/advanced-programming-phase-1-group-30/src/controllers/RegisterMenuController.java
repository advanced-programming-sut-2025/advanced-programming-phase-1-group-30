package controllers;

public class RegisterMenuController {
    public static void register() {}
    public static void ChangeMenu() {}
    public static void ShowCurrentMenu() {}
    public static void Exit() {}
}
