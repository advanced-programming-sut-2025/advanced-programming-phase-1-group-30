package controllers;

public class GameMenuController {
    public static void NewGame() {}
    public static void GameMap() {}
    public static void LoadGame() {}
    public static void ExitGame() {}
    public static void NextTurn() {}
    public static void Time() {}
    public static void Date() {}
    public static void DateTime() {}
    public static void DayOfTheWeek() {}
    public static void CheatAdvanceTime() {}
    public static void CheatAdvanceDate() {}
    public static void Season() {}
    public static void CheatThor() {}
    public static void Weather() {}
    public static void WeatherForecast() {}
    public static void CheatWeatherSet() {}
    public static void GreenHouseBuild() {}
    public static void walk() {}
    public static void PrintMap() {}
    public static void HelpReadingMap() {}
    public static void EnergyShow() {}
    public static void CheatEnergySet() {}
    public static void CheatUnlimitedEnergySet() {}
    public static void InventoryShow() {}
    public static void InventoryTrash() {}
    public static void ToolsEquip() {}
    public static void ShowCurrentTool() {}
    public static void ShowAvailableTools() {}
    public static void UpgradeTools() {}
    public static void ToolUse() {}
    public static void CraftInfo() {}
    public static void Plant() {}
    public static void ShowPlant() {}
    public static void Fertilize() {}
    public static void HowMuchWater() {}
    public static void ShowCraftingRecipe() {}
    public static void Crafting() {}
    public static void PlaceItem() {}
    public static void CheatAddItem() {}
    public static void PutRefrigerator() {}
    public static void PickRefrigerator() {}
    public static void ShowCookingRecipe(){}
    public static void Cooking() {}
    public static void Eat() {}
    public static void Build(){}
    public static void BuyAnimal() {}
    public static void Pet(){}
    public static void CheatSetFriendship() {}
    public static void Animals() {}
    public static void ShepherdAnimals(){}
    public static void FeedHay(){}
    public static void Produces(){}
    public static void CollectProduce(){}
    public static void SellAnimal(){}
    public static void Fishing(){}
    public static void ArtisanUse() {}
    public static void ArtisanGet() {}
    public static void ShowAllProducts() {}
    public static void ShowAvailableProducts() {}
    public static void purchase(){}
    public static void CheatAddMoney(){}
    public static void Sell(){}
    public static void Friendship(){}
    public static void Talk(){}
    public static void TalkHistory(){}
    public static void Gift(){}
    public static void GiftList(){}
    public static void GiftRate(){}
    public static void GiftHistory(){}
    public static void Hug(){}
    public static void Flower(){}
    public static void AskMarriage(){}
    public static void Respond(){}
    public static void StartTrade() {}
    public static void Trade(){}
    public static void TradeList(){}
    public static void TradeResponse(){}
    public static void TradeHistory(){}
    public static void MeetNPC() {}
    public static void GiftNPC() {}
    public static void FriendshipNPCList() {}
    public static void QuestList() {}
    public static void QuestFinish() {}
}
