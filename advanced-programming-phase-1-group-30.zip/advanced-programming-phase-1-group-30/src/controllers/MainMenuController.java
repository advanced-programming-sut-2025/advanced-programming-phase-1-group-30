package controllers;

public class MainMenuController {
    public static void logout() {}
    public static void ChangeMenu() {}
    public static void ShowCurrentMenu() {}
    public static void Exit() {}
}
