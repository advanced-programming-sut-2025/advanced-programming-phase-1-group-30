package controllers;

public class ProfileMenuController {
    public static void ChangeUsername() {}
    public static void ChangeNickname() {}
    public static void ChangeEmail() {}
    public static void ChangePassword() {}
    public static void ChangeMenu() {}
    public static void ShowCurrentMenu() {}
    public static void Exit() {}
}
