package controllers;

public class LoginMenuController {
    public static void Login() {}
    public static void ForgotPassword() {}
    public static void ChangeMenu() {}
    public static void ShowCurrentMenu() {}
    public static void Exit() {}
}
